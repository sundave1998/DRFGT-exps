# first line: 65
        @mem.cache
        def get_data():
            data = load_svmlight_file("a9a")
            return data[0], data[1]
