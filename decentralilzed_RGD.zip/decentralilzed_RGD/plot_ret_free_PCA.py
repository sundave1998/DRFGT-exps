import matplotlib.pyplot as plt
import matplotlib
from matplotlib import rcParams
rcParams.update({'figure.autolayout': True})
import numpy as np
import ast
import pickle

plot_type = 'time' # 'time' or 'iter'

matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42

switcher = {
    'DecenRiemannianGradientStochasticDescent': 'DRSGD',
    'DecenRiemannianGradientTracking': 'DRGTA',
    "DistributedSangerAlg": 'DSA',
    'CenRiemannianGradientStochasticDescent': 'CRSGD',
    "DecenRetrFreeStochasticDescent": 'Ret_free',

}

line_stype = ['-', '--', '--+', '--o', '-1', '-o']


def plot_dist_to_opt(n, log, curve_type, marksize=5, interval=10, linewidth=3):
    t, beta = log.consensus_it, log.grad_stepsize
    beta_0 = 10**4 * beta * pow(400, 0.5) / np.sqrt(n)
    alg_name = switcher.get(log.Algname, "DSA")
    if log.opt_variable is not None:
        # plt.figure(1)
        if plot_type == 'time':
            plt.plot(log.time_history, log.distance_to_opt, curve_type, linewidth=linewidth, markersize=marksize,
                     markevery=len(log.distance_to_opt) // interval,
                     label=alg_name + ', n=' + str(log.size) + ', ' + r'$\hat{\beta}=$' + str(round(beta_0, 3)))  # plot iteration history
        else:
            plt.plot(log.iter_history, log.distance_to_opt, curve_type, linewidth=linewidth, markersize=marksize,
                    markevery=len(log.distance_to_opt) // interval,
                    label=alg_name + ', n=' + str(log.size) + ', ' + r'$\hat{\beta}=$' + str(round(beta_0, 3)))   # plot iteration history
        plt.yscale('log')
        if plot_type == 'time':
            plt.xlabel('CPU time (seconds)', fontsize=14)
        else:
            plt.xlabel('Epoch', fontsize=14)
        plt.ylabel('distance to optimal point', fontsize=14)


def select_best_ret_free(n, stepsize, result, curve_type):
    for i in range(len(stepsize)):
        result.append('MNIST_' + str(n) + '_DRSGD_results/' + 'MPI_' + str(n) + 'DRSRF_' + str(1) +
                      str(stepsize[i]) + '_small_stepsize_MNIST.pkl')
    temp = 10 ** 8
    best_result[n] = 0
    for i in range(len(stepsize)):
        f1 = result[i]
        with open(f1, 'rb') as input:
            Log = pickle.load(input)
            if min(Log.distance_to_opt) < temp:
                temp = min(Log.distance_to_opt)
                best_result[n] = i
    print(best_result[n])
    filename = result[best_result[n]]
    with open(filename, 'rb') as input:
        Log = pickle.load(input)
        # curve_type = line_stype[3]
        plot_dist_to_opt(n, Log, curve_type, marksize=10, interval=15, linewidth=2)


def plot_result(filename):
    lines = []
    with open(filename) as file:
        for line in file:
            line = line.strip()
            lines.append(line)
    time = lines[0]
    time = ast.literal_eval(time)
    print('epoch:', len(time['time']))
    f_obj = lines[1]
    f_obj = ast.literal_eval(f_obj)
    # plt.plot(time['time'], np.array(f_obj['obj val']) - f_min, label=filename)
    plt.plot(np.array(f_obj['obj val']), label=filename)
    plt.legend()
    plt.yscale('log', basey=10)


stepsize_1 = [0.3, 0.4, 0.5, 0.6, 0.7, 0.8]
best_result = {}
#
result_1 = []
select_best_ret_free(16, stepsize_1, result_1, line_stype[1])
#
result_2 = []
stepsize_2 = [0.8, 0.9, 1.0, 1.1]
select_best_ret_free(32, stepsize_1,  result_2, line_stype[1])

result_3 = []
stepsize_3 = [0.01, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2]

select_best_ret_free(60, stepsize_3,  result_3, line_stype[1])

large_font = 15
plt.rc('xtick', labelsize=13)    # fontsize of the x and y labels
plt.xticks(fontsize=large_font)
plt.rc('ytick', labelsize=15)
plt.yticks(fontsize=large_font)
plt.rc('legend', fontsize=13)    # legend fontsize
plt.legend()

import os
if not os.path.isdir("MNIST"):
    os.makedirs("MNIST")
save_path = 'MNIST'
if plot_type == 'time':
    filename = 'PCA' + '_nodes_' + '_ret_free_time' +'.pdf'
else:
    filename = 'PCA' + '_nodes_' + '_ret_free_iter' +'.pdf'

""" add the decentralized results here"""
import plot_acceleration_ratio
# stepsize_1 = [0.2, 0.3, 0.4, 0.5, 0.6, 0.7]
# best_result = {}

# result_1 = []
# select_best(16, stepsize_1, result_1)
#
#
# result_2 = []
# stepsize_2 = [0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
# select_best(32, stepsize_2,  result_2)

# result_3 = []
# stepsize_3 = [0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3]

# select_best(60, stepsize_3,  result_3)

# str=('python plot_acceleration_ratio.py')
# os.system(str)

plt.savefig(os.path.join(save_path, filename), format='pdf', dpi=3000)
plt.show()

