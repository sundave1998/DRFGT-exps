from scipy import sparse
import numpy as np
import warnings


class Quadratic:
    """"
     Quadratic function:  f_i(x) =  -  0.5* sum_{j=1}^num_instances (x'*a_i'*a_i*x)
       #:param num_instances: number of instances at local node
               dimension: dimension of variable
               m:  maximum number of instances across all nodes, only needed for decentralized alg
               data: matrix with size (num_instances, dimension)
               idx: row index of A and y
               eigengap: eigengap of matrix A: lambda_i/ lambda_{i+1}= eigengap
               sparse_mat: whether A is a csr sparse matrix
               x_true: the optimal solution
       #:return a sub-gradient vector:  partial f(x)
       #:return obj val: f(x)
      """
    def __init__(self, num_instances=0, dimension=0, q=0, col=0, A=np.empty([1,1]), B=None, m=1, mu_para_1=0, mu_para_2=0, sparse_mat=False):
        self.num_instances = num_instances
        self.dimension = dimension
        self.q = q
        self.col = col
        self.A = A
        self.B = B
        self.m = m
        self.sparse_mat = sparse_mat
        self.mu_para_1 = mu_para_1
        self.mu_para_2 = mu_para_2
        self.x_true = None
        self.ay = None
        self.bx = None
        self.mu_flag = False # parameter mu should be computed by the function compute_mu
        self.mu = 0

    def synthetic_data(self):
        """ generate synthetic data """
        pho_x = 0.5 # correlation of X
        Sigma_x = pho_x * np.ones([self.dimension, self.dimension])
        Sigma_x = Sigma_x - np.diag(np.diag(Sigma_x)) + np.eye(self.dimension)
        self.A = np.random.multivariate_normal(np.zeros(self.dimension), Sigma_x, size=self.num_instances)
        self.x_true, _ = np.linalg.qr(np.random.randn(self.q, self.col), mode='reduced')
        self.y_true = np.zeros([self.dimension, self.col])
        p_0 = int(np.ceil(0.3*self.dimension))
        self.y_true[:p_0, :] = np.random.randn(p_0, self.col)
        noise = np.random.multivariate_normal(np.zeros(self.q), np.eye(self.q), size=self.num_instances)
        self.B = np.matmul(np.matmul(self.A, self.y_true), self.x_true.T) + 0.1 * noise
        # B = B - np.mean(B, 0)
        # self.B = np.matmul(self.A, np.matmul(self.y_true, self.x_true.T)) +

    def compute_mu(self):
        C_p = np.linalg.solve(np.matmul(self.A.T, self.A), np.matmul(self.A.T, self.B)) # X{i}'*X{i})\(X{i}' * Y{i})
        self.mu = 0.1*self.mu_para_1 * (np.linalg.norm(C_p, axis=1) ** (-self.mu_para_2))
        self.mu_flag = True

    def prox_l21(self, y, t):
        if self.mu_flag is False:
            warnings.warn('regularizer parameter mu is not computed')
        nr = np.linalg.norm(y, axis=1)
        threshold = t*self.mu
        Act_set = (nr > threshold).astype(float)
        return (Act_set*(1 - threshold/nr))[:, np.newaxis] * y

    def regularizer(self, y):
        nr = np.linalg.norm(y, axis=1)
        return np.sum(self.mu*nr)

    def obj_X(self, x, y, idx, n=1, return_objval=True):
        """"
            :param return_objval: whether return objective value
            :param sparse_mat: whether A is a csr sparse matrix
            :return gradient: A'*A*x
            :return obj val: 0.5*Tr(x'*A'*A*x)
        """
        if not self.sparse_mat:
            full_idx = np.arange(self.num_instances)
            if idx.size == full_idx.size and (idx == full_idx).all():
                """full grad """
                self.ay = np.matmul(self.A, y)
                grad = -np.matmul(self.B.T, self.ay)
            elif idx.size == 0:
                """ empty idx """
                return np.zeros(x.shape), None
            else:
                """ batch grad """
                self.ay = np.matmul(self.A[idx, :], self.y)  # m*1
                grad = -np.matmul(self.B[idx, :].T, self.ay)
            if return_objval is False:
                return grad, None
            else:
                return grad, -0.5 * np.sum(np.trace(np.matmul(self.ay.T, self.ay))) # not right
        else:
            " sparse matrix "
            full_idx = np.arange(self.num_instances)
            if idx.size == full_idx.size and (idx == full_idx).all():
                """full grad """
                ax = sparse.csr_matrix.dot(self.A, x)
                grad = sparse.csr_matrix.dot(self.A.T, ax)
            elif idx.size == 0:
                """ empty idx """
                return np.zeros(x.shape), None
            else:
                """ batch grad """
                if idx.size == 1:
                    idx = int(idx)
                    d1 = self.A.data[self.A.indptr[idx]:self.A.indptr[idx + 1]]
                    i1 = self.A.indices[self.A.indptr[idx]:self.A.indptr[idx + 1]]
                    a_dense = np.zeros(x.size)
                    a_dense[i1] = d1
                    ax = np.dot(a_dense, x)
                    grad = np.dot(a_dense.T, ax)
                else:
                    a1 = self.A[idx, :]
                    ax = sparse.csr_matrix.dot(a1.T, x)
                    grad = sparse.csr_matrix.dot(a1.T, ax)

            if return_objval is False:
                return grad, None
            else:
                return grad, -0.5 * np.sum(np.trace(np.matmul(ax.T, ax)))

    def obj_Y(self, x, y, idx, n=1, return_objval=True):
        """"
            :param return_objval: whether return objective value
            :param sparse_mat: whether A is a csr sparse matrix
            :return gradient: A'*A*x
            :return obj val: 0.5*Tr(x'*A'*A*x)
        """
        if not self.sparse_mat:
            full_idx = np.arange(self.num_instances)
            if idx.size == full_idx.size and (idx == full_idx).all():
                """full grad """
                # self.ay = np.matmul(self.A, y)  # we firstly update x, A*Y was computed and saved
                # self.ay = np.matmul(self.A, y)
                self.bx = np.matmul(self.B, x)
                grad = np.matmul(self.A.T, self.ay - self.bx)
            elif idx.size == 0:
                """ empty idx """
                return np.zeros(x.shape), None
            else:
                """ batch grad """
                ax = np.matmul(self.A[idx, :], x)  # m*1
                grad = np.matmul(self.A[idx, :].T, ax)
            if return_objval is False:
                return grad, None
            else:
                return grad, np.linalg.norm(self.ay)**2 - 2*np.einsum('ij,ij->', self.ay, self.bx) + np.linalg.norm(self.bx)**2 + self.regularizer(y)
        else:
            " sparse matrix "
            full_idx = np.arange(self.num_instances)
            if idx.size == full_idx.size and (idx == full_idx).all():
                """full grad """
                ax = sparse.csr_matrix.dot(self.A, x)
                grad = sparse.csr_matrix.dot(self.A.T, ax)
            elif idx.size == 0:
                """ empty idx """
                return np.zeros(x.shape), None
            else:
                """ batch grad """
                if idx.size == 1:
                    idx = int(idx)
                    d1 = self.A.data[self.A.indptr[idx]:self.A.indptr[idx + 1]]
                    i1 = self.A.indices[self.A.indptr[idx]:self.A.indptr[idx + 1]]
                    a_dense = np.zeros(x.size)
                    a_dense[i1] = d1
                    ax = np.dot(a_dense, x)
                    grad = np.dot(a_dense.T, ax)
                else:
                    a1 = self.A[idx, :]
                    ax = sparse.csr_matrix.dot(a1.T, x)
                    grad = sparse.csr_matrix.dot(a1.T, ax)

            if return_objval is False:
                return -grad, None
            else:
                return -grad, -0.5 * np.sum(np.trace(np.matmul(ax.T, ax)))


if __name__ == '__main__':
    import numpy.linalg as la
    import time
    from misc.ManifoldToolbox import StiefelManifold

    sparse_mat = False
    num_instances, var_dim, q, var_col = 250, 30, 10, 3
    mu_para_1, mu_para_2 = 1, 2
    model = Quadratic(num_instances=num_instances, dimension=var_dim, q=q, col=var_col,  m=1,
                      mu_para_1=mu_para_1, mu_para_2=mu_para_2)
    model.synthetic_data()
    model.compute_mu()
    C_true = np.matmul(model.y_true, model.x_true.T)
    batch_size = 'full'
    print('batch size:', batch_size)
    Epoch = 1000
    tol = 1e-16
    stepsize_type = ['1/k', '1/sqrtk', 'constant']

    step_size_t = stepsize_type[2]
    if isinstance(batch_size, int):
        # 50 * batch_size / (num_instances * Epoch * np.sqrt(dimension))
        step_init = 0.001
    else:
        step_init = 0.0001

    np.random.seed(2021)
    x_start = np.random.randn(q, var_col)
    x_start = StiefelManifold.proj_manifold(x_start)
    y_start = np.ones([var_dim, var_col])
    obj_val = []
    Err = []
    grad_norm = []
    time_record = []

    def local_objective_X(x, y, idx, comp_objval=False):
        # local objective func
        return model.obj_X(x, y, idx, return_objval=comp_objval)

    def local_objective_Y(x, y, idx, comp_objval=True):
        # local objective func
        return model.obj_Y(x, y, idx, return_objval=comp_objval)

    # def objective_Y(x, y, idx, return_objval=True):
    #     return model.obj_Y(x=x, y=y, idx=idx, return_objval=return_objval)

    start_time = time.time()
    step_beta_x = 0.001
    step_beta_y = step_init

    x, y = x_start, y_start
    for i in range(Epoch):
        if batch_size == 'full':
            """ full gradient """
            idx = np.arange(model.num_instances)

            if step_size_t == '1/sqrtk':
                step_beta_x = step_init / np.sqrt(i)
            elif step_size_t == '1/k':
                step_beta_x = step_init / i
            elif step_size_t == 'constant':
                step_beta_x = step_init

            if step_beta_x < tol:
                break
            grad_x, _ = local_objective_X(x, y, idx=idx)

            direction_x = StiefelManifold.proj_tangent(x, -step_beta_x * grad_x)
            """  update  variable  x """
            x = StiefelManifold.retraction(x, direction_x)

            grad_y, objective_val = local_objective_Y(x, y, idx=idx)
            """  update  variable  y """
            y = model.prox_l21(y - step_beta_y * grad_y, step_beta_y)
        else:
            """ stochastic gradient step, one epoch """
            if step_size_t == '1/sqrtk':
                step_size = step_init / np.sqrt(i)
            elif step_size_t == '1/k':
                step_size = step_init / i
            elif step_size_t == 'constant':
                step_size = step_init

            if step_size < tol:
                break
            num = np.int(np.ceil(num_instances / batch_size))
            sample = np.random.permutation(num_instances)
            end = 0
            for _ in range(num):
                # idx = np.random.randint(0, num_instances, batch_size)
                start = end
                end = start + batch_size
                idx = sample[start: end]
                grad_x, _ = local_objective_X(x, y, idx=idx)
                x += step_size * grad

            grad, fval = local_objective_X(x, y, idx=np.arange(num_instances), return_objval=True)
        # print(step_size)
        time_record.append(time.time() - start_time)
        # x = x - np.power(0.9, i)*subg
        Err.append(la.norm(C_true-np.matmul(y, x.T)))
        obj_val.append(objective_val)
        grad_norm.append(la.norm(grad_x))

    # print('time', time.time() - start_time)
    # print({'time': time_record})
    # print({'obj val': obj_val})

    import matplotlib.pyplot as plt

    plt.plot(Err)
    plt.yscale('log', base=10)
    plt.xlabel('Epoch')
    plt.ylabel('Error')
    # plt.ylabel(r'$f( {X}_k) - f^*$')
    plt.show()
