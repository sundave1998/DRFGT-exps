""" Time Decorator"""

import time


def timeit(func):
    def wrapper(*args):
        start = time.time()
        for i in range(10000):
            result = func(*args)
        end = time.time()
        print(f'total time is {end-start}')
        return result
    return wrapper


if __name__ == '__main__':
    import numpy as np
    m, n = 10**4, 10**2
    A = np.random.randn(m, n)
    row_x = np.random.rand(n)
    col_x = np.random.rand(n, 1)


    @timeit
    def rand_test():
        y = np.matmul(A, row_x)
        # print(a)
        # print(TimeConsensus.consensus_time)


    @timeit
    def rand_test2():
        y = np.matmul(A, col_x)
    
    rand_test()
    rand_test2()


