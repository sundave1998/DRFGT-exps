import numpy as np
from scipy import sparse
from scipy.sparse import csr_matrix
import time


def timeit(func):
    def wrapper(*args):
        start = time.time()
        for i in range(10000):
            result = func(*args)
        end = time.time()
        print(f'total time is {end-start}')
        return result
    return wrapper


m, n = 10**3, 10**3
A = (sparse.rand(m, n, 0.1, 'csr')*20).floor()
B = A.A
x = np.random.rand(n)


@timeit
def sparse_take_idx(A):
    a = A[4:6, :]
    c = sparse.csr_matrix.dot(a, x)
    return c


@timeit
def sparse_take_idx_alt(A):
    d1 = A.data[A.indptr[4]:A.indptr[6]]
    i1 = A.indices[A.indptr[4]:A.indptr[6]]
    a = np.zeros(x.size)
    a[i1] = d1
    # col = np.zeros(i1.size)
    # sparse.coo_matrix((d1, (col, i1)), shape=(1, 123))
    # c = np.dot(d1, x[i1])
    c = np.dot(a, x)
    return c


@timeit
def dense_take_idx(B):
    a = B[4:6, :]
    c = np.dot(a, x)
    return c


c1 = sparse_take_idx(A)
c2 = sparse_take_idx_alt(A)
c3 = dense_take_idx(B)