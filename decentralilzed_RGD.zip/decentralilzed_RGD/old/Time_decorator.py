import time


def timeit(func):
    def wrapper(*args):
        start = time.time()
        result = func(*args)
        # end = time.time()
        # print(f'total time is {end-start}')
        return result, time.time()-start
    return wrapper


if __name__ == '__main__':
    import numpy as np

    class Thing(object):
        def __init__(self, name):
            self.name = name
            self.A = 'hh'
            self.B = 'aa'

        def timeit(func):
            def wrapper(*args):
                self = args[0]
                start = time.time()
                print(time.time() - start)
                return func(*args)

            return wrapper

        @timeit
        def local_objective(self):
            x, y = self.A, self.B
            return self.change(new_name_1=x, new_name_2=y)

        def debug_name(function):
            def debug_wrapper(*args, **kargs):
                self = args[0]
                print('self.name = ' + self.name)

                print('running function {}()'.format(function.__name__))
                function(*args, **kargs)
                print('self.name = ' + self.name)

            return debug_wrapper

        @debug_name
        def set_name(self, new_name_1, new_name_2):
            self.name = new_name_1 + new_name_2

        def change(self, new_name_1, new_name_2):
            return self.set_name(new_name_1, new_name_2)


    x = np.random.rand(100, 10)

    def f(A, B):
        return np.matmul(A, B)

    @timeit
    def compute(A, B=x):
        return f(A=A, B=B)

    A = np.random.randn(100, 100)
    B = np.random.rand(100, 1000)
    C, CPU_time = compute(A, B)
    print(CPU_time)

    a = Thing('A')
    a.change('B', 'C')
    # a.set_name('a', new_name_2=2)  # wrong since the second is dic, should use **kargs
    a.set_name('a', new_name_2='b')