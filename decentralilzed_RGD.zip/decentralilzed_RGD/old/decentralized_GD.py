""" Decentralized Riemannian Gradient Tracking method on Stiefel manifold. """
import time
import numpy as np
import scipy.linalg as la
from mpi4py import MPI
from misc.Consensus import Consensus

comm = MPI.COMM_WORLD
size = MPI.COMM_WORLD.Get_size()
rank = MPI.COMM_WORLD.Get_rank()
# name = MPI.Get_processor_name()


class DecenRiemannianGradient(Consensus):
    def __init__(self,
                 objective,
                 manifold,
                 arg_start,
                 synch=True,
                 weight=[],
                 step_size_consensus=1,
                 step_size_grad=None,
                 terminate_by_time=False,
                 termination_condition=None,
                 log=False,
                 num_consensus_itr=1):
        """ Initialize the decentralized optimization settings. """
        self.objective = objective
        self.manifold = manifold
        self.arg_start = arg_start
        self.step_size_consensus = step_size_consensus
        self.step_size_grad = step_size_grad
        self.weight = weight
        self.terminate_by_time = terminate_by_time
        self.termination_condition = termination_condition
        self.log = log
        """ Initialize the MPI settings. """
        super(DecenRiemannianGradientTracking,   self).__init__(variable=arg_start,
                                                                synch=synch,
                                                                weight=self.weight,
                                                                terminate_by_time=terminate_by_time,
                                                                termination_condition=termination_condition,
                                                                num_consensus_itr=num_consensus_itr)

    def proj_tangent(self, x, d):
        return self.manifold.proj_tagent(x, d)

    def retraction(self, x, d):
        return self.manifold.retraction(x, d)

    def minimize(self):
        consensus = self.consensus
        objective = self.objective
        proj_tangent = self.proj_tangent
        retraction = self.retraction
        Iter = 0
        step_alpha = self.step_size_consensus
        step_beta = self.step_size_grad
        x = self.arg_start  # initial variable
        grad, objective_val = objective(x)
        rgrad = proj_tangent(x, grad)  # Riemannian gradient
        tracking_grad = rgrad   # gradient tracking variable
        rgrad_old = rgrad

        # set up log
        log = self.log
        if log:
            from logfile import Log
            RGD_log = Log()  # Log the variable, gradient, iteration

        if not self.terminate_by_time:
            num_iter_RGD = self.termination_condition
            stop_criteria = Iter < num_iter_RGD
        else:
            end_time = time.time() + self.termination_condition
            stop_criteria = time.time() < end_time

        stop_condition_global = True
        # Start optimization at the same time
        comm.Barrier()  # no process could pass this barrier until they all call it
        # loop of the decentralized Riemannian gradient tracking method
        while stop_criteria:
            if self.synch:
                comm.Barrier()  # synchronize

            # multi-step consensus
            comm_vector = np.append(x, tracking_grad)
            comm_result = consensus(comm_vector)

            # update consensus step
            local_average = comm_result[:x.size].reshape(self.arg_start.shape) - x
            consensus_grad = proj_tangent(x, local_average)
            # -- update RGD-tracking iteration  -- #
            v = proj_tangent(x, tracking_grad)
            x = retraction(x, step_alpha*consensus_grad - step_beta*v)
            grad, objective_val = objective(x)
            # update Riemannian gradient
            rgrad = proj_tangent(x, grad)
            # update gradient tracking estimate
            tracking_grad = comm_result[x.size:].reshape(self.arg_start.shape)
            tracking_grad += rgrad - rgrad_old

            # Update the past gradient (at itr. k minus 1)
            rgrad_old = rgrad
            norm_tracking_grad = la.norm(tracking_grad)

            global_obj_val = np.empty(1)
            if objective_val:
                comm.Reduce(objective_val, global_obj_val, MPI.SUM, root=0)
            if rank == 0:
                if log:
                    RGD_log.log(norm_tracking_grad, Iter, objval=global_obj_val / size)
                if norm_tracking_grad < 1e-15:
                    stop_condition_global = False

            Iter += 1
            if self.terminate_by_time is False:
                stop_criteria = Iter < num_iter_RGD
            else:
                end_time = time.time() + self.termination_condition
                stop_criteria = time.time() < end_time

            stop_condition_global = comm.bcast(stop_condition_global, root=0)  # broadcast from root 0 to all roots
            stop_criteria = (stop_criteria and stop_condition_global)

        # compute the average point and average gradient
        average_variable = np.empty(grad.shape, dtype=np.float)/size
        comm.Reduce(x, average_variable, MPI.SUM, root=0)
        average_grad = np.empty(grad.shape, dtype=np.float)
        comm.Reduce(rgrad, average_grad, MPI.SUM, root=0)    # collection average gradient to root 0
        ave_grad_norm = la.norm(average_grad)/size
        if rank == 0:
            # self.argmin_est = x
            if log:
                RGD_log.log(ave_variable=average_variable, ave_grad_norm=ave_grad_norm)
                return {"Log": RGD_log}
            else:
                return {"ave_variable": average_variable,
                        "ave_gradient": ave_grad_norm}
        return None
