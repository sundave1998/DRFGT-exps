from misc.ManifoldToolbox import subspace_distance as d1
from misc.ManifoldToolbox import subspace_distance_nonorthogonal as d2
import numpy as np

d, r = 5, 3
x = np.random.randn(d, r)
y = np.random.randn(d, r)
O = np.random.randn(r, r)
# O, _, _ = np.linalg.svd(O, full_matrices=False)
x = np.matmul(y, O)
u, _, _ = np.linalg.svd(x, full_matrices=False)
v, _, _ = np.linalg.svd(y, full_matrices=False)


def d3(x, y):
    u, _, _ = np.linalg.svd(x, full_matrices=False)
    v, _, _ = np.linalg.svd(y, full_matrices=False)
    a = 0
    for i in range(u.shape[1]):
        a += 1 - (np.dot(u[:, i], v[:, i]))**2
    return a


print(d1(u, v))
print(d2(x, y))
print(d3(x, y))