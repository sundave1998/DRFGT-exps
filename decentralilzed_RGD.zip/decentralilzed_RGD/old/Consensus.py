"""
consensus on Stiefel manifold: Riemannain gradient method
"""
import numpy as np
import numpy.linalg as la
from mpi4py import MPI
import warnings

comm = MPI.COMM_WORLD
size = MPI.COMM_WORLD.Get_size()
rank = MPI.COMM_WORLD.Get_rank()
# Default values
default_consensus_iter = 1
default_time = 1    # time in seconds


class Consensus(object):
    """
    :param variable: Estimate of the argument that minimizes the sum of nodes' objectives
    :param synch: Whether to run the alg. synchronously (or asynchronously)
    :param terminate_by_time: Whether to terminate the alg. after some threshold time
    :param termination_condition: stopping criterion, e.g. iteration number 100, termination_condition = 100
    :param num_consensus_itr: multi-step consensus numbers
    """

    def __init__(self, variable,
                 synch=True,
                 weight=[],
                 terminate_by_time=False,
                 termination_condition=None,
                 num_consensus_itr=1):
        self.variable = np.array(variable)
        self.synch = synch
        if weight == []:
            warnings.warn("no doubly stochastic matrix provided!")

        self.weight = weight
        self.peer = []
        for i in range(size):
            if self.weight[i] > 0 and i != rank:
                self.peer.append(i)
        self.terminate_by_time = terminate_by_time

        # Set the termination condition to the class defaults if not specified
        if not termination_condition:
            if terminate_by_time:
                self.termination_condition = default_time
            else:
                self.termination_condition = default_consensus_iter
        else:
            self.termination_condition = termination_condition

        self.num_consensus_itr = num_consensus_itr

        if self.synch and self.terminate_by_time:
            warnings.warn("Use of synchronous w/ time term. cond. will result in deadlocks.")

    def send_to_neighbors(self, x):
        for i in self.peer:
            # if self.weight[i] > 0 and i != rank:
            comm.Send(x, dest=i, tag=rank)

    def collect_from_neighbors(self, x):
        x = x * self.weight[rank]
        for i in self.peer:
            # if self.weight[i] > 0 and i != rank:
            status = MPI.Status()
            while not comm.Probe(source=MPI.ANY_SOURCE, status=status):
                pass
            recvbuf = np.empty(x.shape, dtype=np.float64)
            comm.Recv(recvbuf, source=i)
            x += self.weight[i] * recvbuf
            del status
        return x

    def consensus(self, x):
        for _ in range(self.num_consensus_itr):
            # if self.synch is True:
                # comm.Barrier()
            self.send_to_neighbors(x)
            x = self.collect_from_neighbors(x)
        return x

    @staticmethod
    def compute_manifold_mean(x, manifold):
        euclidean_average_variable = np.empty(x.shape, dtype=np.float64)
        comm.Allreduce(x, euclidean_average_variable, MPI.SUM)
        euclidean_average_variable = euclidean_average_variable / size
        manifold_average_variable = manifold.proj_manifold(euclidean_average_variable)
        return manifold_average_variable

    @staticmethod
    def compute_at_mean(manifold_average_variable, x, manifold, objective):
        local_distance_to_mean = la.norm(manifold_average_variable - x) ** 2
        consensus_error = comm.reduce(local_distance_to_mean, MPI.SUM, root=0)
        if rank == 0:
            consensus_error = np.sqrt(consensus_error)
        local_grad_ave, local_obj_val_ave = objective(manifold_average_variable)
        sendbuf = np.append(local_grad_ave, local_obj_val_ave)
        if rank == 0:
            recv_buf = np.empty(sendbuf.size)
        else:
            recv_buf = None
        comm.Reduce(sendbuf, recv_buf, MPI.SUM, root=0)
        obj_val_ave = np.empty(1, np.float64)
        ave_grad_norm = np.empty(1, np.float64)
        if rank == 0:
            grad_ave = recv_buf[:-1].reshape(x.shape) / size
            obj_val_ave = recv_buf[-1] / size
            rgrad_ave = manifold.proj_tangent(manifold_average_variable, grad_ave)
            ave_grad_norm = la.norm(rgrad_ave)
        return consensus_error, obj_val_ave, ave_grad_norm

