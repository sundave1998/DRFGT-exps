from mpi4py import MPI
import numpy as np

import time
comm = MPI.COMM_WORLD
size = comm.Get_size()
rank = comm.Get_rank()
m, n = 1, 1
randNum = np.array([12.1])  #np.array(121, dtype=np.float)

if rank == 0:
    for i in range(1, size):
        sendbuf = randNum
        comm.Send(sendbuf, dest=i)
else:
    recvbuf = np.empty(2)
    comm.Recv(recvbuf, source=0)
    print(recvbuf)
# start_t = time.time()
# recv_buf = np.empty(1, dtype=np.float)
# comm.Reduce(randNum, recv_buf, op=MPI.SUM, root=0)
#
# if rank == 0:
#     print("time is ", time.time()-start_t)
#     print('my num is', randNum)
#     print('sum is', recv_buf)



# send_buf = np.array([0, 1], dtype='i') + 2 * rank
# if rank == 2:
#     recv_buf = np.empty(2, dtype='i')
# else:
#     recv_buf = None
#
# # Reduce by SUM: [0, 1] + [2, 3] + [4, 5] + [6, 7] = [12, 16]
# comm.Reduce(send_buf, recv_buf, op=MPI.SUM, root=2)
# print('Reduce by SUM: rank %d has %s' % (rank, recv_buf))

