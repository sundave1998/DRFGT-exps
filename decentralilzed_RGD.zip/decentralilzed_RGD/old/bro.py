from mpi4py import MPI
import numpy as np
from misc.Graph import Graph
from scipy.sparse import csr_matrix

comm = MPI.COMM_WORLD
size = comm.Get_size()
rank = comm.Get_rank()
randNum = np.zeros(1)

# from sklearn.datasets import fetch_rcv1
# rcv1 = fetch_rcv1()
# global_data = rcv1.data
row = np.array([0, 0, 1, 2, 2, 2])
col = np.array([0, 2, 2, 0, 1, 2])
data = np.array([1, 2, 3, 4, 5, 6])
global_data = csr_matrix((data, (row, col)), shape=(3, 3))
print(global_data.shape)
Num_instances = global_data.shape[0]
Dimension = global_data.shape[1]
number_agent = size
count = Num_instances // size
remainder = Num_instances % size

indpr = global_data.indptr
indices = global_data.indices
data = global_data.data
print('rank', rank)

if rank == 0:

    # Global_data = np.random.randn(Num_instances, Dimension)

    graph_type = ['Ring', 'ER']
    weighted_type = ['max_degree', 'metropolis_hastings']
    graph = Graph(graph_type=graph_type[0], weighted_type=weighted_type[0],
                  N=number_agent, p=0.3, plot_g=False)
    print(graph.peer)
    if rank < remainder:
        # The first 'remainder' ranks get 'count + 1' tasks each
        start = 0
        stop = start + count
    else:
        # The remaining 'size - remainder' ranks get 'count' task each
        start = 0
        stop = start + (count - 1)
    local_row = indpr[start:stop+1]
    weighted = graph.W[0, :]
    peer = graph.peer[0]
    for i in range(1, size):
        if i < remainder:
            # The first 'remainder' ranks get 'count + 1' tasks each
            start = i * (count + 1)
            stop = start + count
        else:
            # The remaining 'size - remainder' ranks get 'count' task each
            start = i * count
            stop = start + (count - 1)
        # sendbuf = np.append(np.append(Global_data[start:stop+1,:], graph.W[i, :]), graph.peer[i])
        local_row = indpr[start:stop + 1]

        sendbuf = np.append(global_data[start:stop+1,:], graph.W[i, :])
        comm.Send(sendbuf, dest=i)

elif rank < remainder:
    recvbuf = np.empty((count+1)*Dimension + number_agent)
    peer = np.empty(size)
    weighted = np.empty(size)
    comm.Recv(recvbuf, source=0)
    local_data = recvbuf[:(count+1)*Dimension].reshape(count+1, Dimension)
    weighted = recvbuf[(count+1)*Dimension:(count+1)*Dimension+size].reshape(size)
    # peer = recvbuf[(count+1)*Dimension+size:]
    #print('weight=', weighted)


else:
    recvbuf = np.empty(count*Dimension + number_agent)
    peer = np.empty(size)
    weighted = np.empty(size)
    comm.Recv(recvbuf, source=0)
    local_data = recvbuf[:count*Dimension].reshape(count, Dimension)
    weighted = recvbuf[count*Dimension:].reshape(size)
    # peer = recvbuf[count*Dimension+size:]
    #print('weight=', weighted)


class Consensus:
    def __init__(self, x, synch):
        self.weight = weighted
        self.num_consensus_itr = 30
        self.variable = x
        self.synch = synch

    def send_to_neighbors(self, x):
        for i in range(size):
            if self.weight[i] > 0 and i != rank:
                comm.Send(x, dest=i, tag=rank)

    def collect_from_neighbors(self, x):
        x = x * self.weight[rank]
        for i in range(size):
            if self.weight[i] > 0 and i != rank:
                status = MPI.Status()
                while not comm.Probe(source=MPI.ANY_SOURCE, status=status):
                    pass
                recvbuf = np.empty(x.shape, dtype=np.float64)
                comm.Recv(recvbuf, source=i)
                x += self.weight[i] * recvbuf #.reshape(x.shape)
                # print(self.variable, 'tag=', status.tag)
                del status
        return x

    def consensus(self, x):
        #shape = x.shape
        #x = x.reshape(x.size)
        for _ in range(self.num_consensus_itr):
            if self.synch is True:
                comm.Barrier()
            self.send_to_neighbors(x)
            x = self.collect_from_neighbors(x)
        return x#.reshape(shape)


synch = True
x = np.random.randn(2, 2)
A = Consensus(x, synch)
x = A.consensus(x)
print(x)
# if synch is True:
#     comm.Barrier()
# for i in range(size):
#     if weighted[i] > 0 and i != rank:
#         comm.Isend(x, dest=i, tag=rank)
#
# x = x*weighted[rank]
# for i in range(size):
#     if weighted[i] > 0 and i != rank:
#         status = MPI.Status()
#         while not comm.Iprobe(source=MPI.ANY_SOURCE, status=status):
#             print('waiting')
#
#         recvbuf = np.empty(x.size, dtype=np.float64)
#         comm.Recv(recvbuf, source=status.source)
#         x += weighted[i]*recvbuf.reshape(x.shape)
#         # print(x, 'tag=', status.tag)
#         del status