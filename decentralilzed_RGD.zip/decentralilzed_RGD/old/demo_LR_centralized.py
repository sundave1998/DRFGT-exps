import numpy as np
from mpi4py import MPI
import time
from scipy import sparse

from misc.Graph import Graph
from Logistic_regression import LogisticRegression
from centralized_RGD import CenRiemannianGradient
from misc.ManifoldToolbox import Euclidean
from misc.Consensus import EuclideanConsensus

"""
Demo of Riemannian decentralized   gradient method for solving
            max_X 1/N * sum_{i=1}^N f_i(x_i)
            s.t.  x_1 = x_2 = ... x_N and x_i  in manifold
        where N is the number of devices
        f_i(x_i) = 1/m_i * sum_{j=1}^m_i | (a_j^T x_i)^2 - y_j |
        A is data matrix with size of (row, col) = (matrix_row_n , matrix_col_n)
        A_i is obtained by divided A into N partitions
        x_i's size: matrix_col_n, 1
"""

comm = MPI.COMM_WORLD
size = MPI.COMM_WORLD.Get_size()
rank = MPI.COMM_WORLD.Get_rank()


def demo(data_size, graph_setting, manifold=Euclidean, consensus_stepsize=1, multi_step_consen=1,  batch_size='full',
         stepsize_type='1/k', grad_stepsize=0, termination_cond=(1e2, 1e-8), stop_by_time=False,  plot=True, comp_objval=True, record_consensus_error=True):
    """
    Demo for the use of the decentralized RGD.
       #:param data_size = (matrix_row_n, matrix_col_n, var_col_n)
               graph_setting: network graph setting
               manifold: the type of manifold
               consensus_stepsize: stepsize of consensus
               multi_step_consen: number of consensus iteration
               batch_size:  if full gradient is computed, set batch_size='full' ; else set the number of batch size
               stepsize_type: type of stepsize for gradient step
               grad_stepsize: stepsize of gradient step
               termination_cond=(iteration number/epoch number, tol): stopping criterion,
               plot: plot the objective values and gradient norm if plot is True and log_ is True
               comp_objval: whether compute objective value
               record_consensus_error:  if you want to get the consensus error, this would be slow.

    """
    num_instances = data_size[0]
    dimension = data_size[1]
    count = num_instances // size
    remainder = num_instances % size
    sparse_mat = False
    reg = 1e-5
    if rank < remainder:
        ni = count + 1
    else:
        ni = count

    CONS = EuclideanConsensus(synch=True,
                              terminate_by_time=stop_by_time,
                              num_consensus_itr=multi_step_consen)
    start_time = time.time()
    """"create model"""
    if rank == 0:
        # from joblib import Memory
        # from sklearn.datasets import load_svmlight_file
        # mem = Memory("./mycache")
        #
        # @mem.cache
        # def get_data():
        #     data = load_svmlight_file("a9a")
        #     return data[0], data[1]
        #
        # data_mat, y = get_data()

        with open('a9a_mat.npz', 'rb') as f:
            data_mat = sparse.load_npz(f)
        f.close()
        with open('a9a_label.npy', 'rb') as f:
            y = np.load(f)
        f.close()
        data_mat = data_mat.A # transform into dense matrix
        num_instances, dimension = data_mat.shape
        global_model = LogisticRegression(num_instances, dimension, A=data_mat, y=y, regularization=reg, sparse_mat=sparse_mat)

        # global_model = LogisticRegression(num_instances, dimension, regularization=reg,
        #                                   sparse_mat=sparse_mat)
        # global_model.synthetic_data()
        print("data matrix shape:", global_model.A.shape, ";", "variable shape:", (global_model.A.shape[1], 1))
        del data_mat, y
        global_data = global_model.A1
        """ initial point """
        x_start = global_model.init_point()  # initialization
        x_start = manifold.proj_manifold(x_start)

        graph = Graph(graph_type=graph_setting[0], weighted_type=graph_setting[1],
                      N=size, p=graph_setting[2], plot_g=False)
        print("The peers of graph:", graph.peer)
    else:
        global_data = None
        graph = None
        x_start = np.empty(dimension)

    """ partition data matrix"""

    CONS.partition_data_mat(global_data, dimension, graph, count, remainder, csr_sparse=sparse_mat)
    comm.Bcast(x_start, root=0)

    print("rank=", rank)
    print("partition data time:", time.time() - start_time)
    print("local data size:", CONS.local_data.shape, '\n')
    """"create local model"""
    local_model = LogisticRegression(num_instances=ni,
                                     dimension=dimension,
                                     m=count+1,
                                     A1=CONS.local_data,
                                     regularization=reg,
                                     sparse_mat=sparse_mat)

    if rank == 0:
        from logfile import Log
        DRG_log = Log()
        # DRG_log.log(opt_var=x_true)
        DRG_log.log(opt_objval=0)
    else:
        DRG_log = None
    alg = CenRiemannianGradient(CONS=CONS,
                                  local_model=local_model,
                                  manifold=manifold,
                                  arg_start=x_start,
                                  synch=True,
                                  step_size_consensus=consensus_stepsize,
                                  batch_size=batch_size,
                                  step_size_type=stepsize_type,
                                  step_size_grad=grad_stepsize,
                                  terminate_by_time=False,
                                  termination_condition=termination_cond,
                                  record_consensus_error=record_consensus_error,
                                  log=DRG_log, comp_objval=comp_objval)
    """ run the algorithm """
    alg_log = alg.minimize()

    if rank == 0 and alg.log:
        print('obj function time', alg.time_obj)
        logfile = alg_log['Log']
        time.sleep(1)
        logfile.print_rgd_value()  # print result
        if plot and record_consensus_error:
            from misc.Plot import plot
            plot(logfile, objval=comp_objval)

    return alg_log


'''==================================================================='''

""" 
set data shape
"""
matrix_row_n, matrix_col_n = 32561, 123

"""  
set graph 
"""
graph_type = ['Ring', 'ER']
weighted_type = ['max_degree', 'metropolis_hastings']
Er_p = 0.3
graph_set = (graph_type[0], weighted_type[0], Er_p)

"""
set stepsize 
    if stepsize_type == '1/k':
        stepsize = grad_stepsize[0]/iteration
    if stepsize_type == '1/sqrtk':
        stepsize = grad_stepsize[0]/sqrt(iteration)
    if stepsize_type == 'constant':
        stepsize = grad_stepsize[0]  
"""
stepsize_type = ['1/k', '1/sqrtk', 'constant']
batch_size = 1  # 'full' for deterministic algorithm
Epoch = 50
tol = 1e-17
count = matrix_row_n // size
remainder = matrix_row_n % size
ni = count + 1 if rank < remainder else count

if isinstance(batch_size, int):
    # 50 * batch_size / (num_instances * Epoch * np.sqrt(dimension))
    stepsize = 0.01
else:
    stepsize = 0.1

if rank == 0:
    print('initial stepsize', stepsize)
"""
size          10**5  10**2
node        16    32   64   128
stepsize    1     1     1    1
gamma      0.85 0.85  0.88 
"""
""" run demo of robust phase retrieval """
Result = demo(data_size=(matrix_row_n, matrix_col_n),
              graph_setting=graph_set,
              manifold=Euclidean,
              consensus_stepsize=1,
              multi_step_consen=1,
              stepsize_type=stepsize_type[-1],
              grad_stepsize=[stepsize, 0.99],
              batch_size=batch_size,
              termination_cond=(Epoch, tol),
              comp_objval=True,
              record_consensus_error=True,
              plot=True)

