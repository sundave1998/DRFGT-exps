import numpy as np
import scipy
from scipy import sparse
import numpy.linalg as la


def sigmoid(X, weight, sparse_mat=False):
    if not sparse_mat:
        z = np.dot(X, weight)
    else:
        z = sparse.csr_matrix.dot(X, weight)
    return 1 / (1 + np.exp(-z))


class LogisticRegression:

    def __init__(self, num_instances=0, dimension=0, m=1, A=None, y=None,
                 A1=None, x_true=[], regularization=0, sparse_mat=False):
        self.num_instances = num_instances
        self.dimension = dimension
        self.m = m
        self.A = A
        self.y = y
        if A is not None and A1 is None:
            if sparse_mat:
                self.A1 = self.A.multiply(self.y[:, np.newaxis])
                self.A1 = self.A1.tocsr()
            else:
                self.A1 = (self.A.T * self.y).T
        else:
            self.A1 = A1
        self.x_true = x_true
        self.sparse_mat = sparse_mat
        self.reg = regularization

    def synthetic_data(self):
        """ generate data """
        if not self.sparse_mat:
            np.random.seed(2021)
            self.x_true = np.random.randn(self.dimension)
            self.A = np.random.randn(self.num_instances, self.dimension)
            self.y = np.sign(np.dot(self.A, self.x_true))
            self.A1 = (self.A.T * self.y).T
        else:
            from scipy.sparse import random
            # from scipy import stats
            self.A = random(self.num_instances, self.dimension, density=0.5, format='csr')
            self.A.data[:] = 1
            self.x_true = np.random.randn(self.dimension)
            self.y = np.sign(sparse.csr_matrix.dot(self.A, self.x_true))
            self.A1 = self.A.multiply(self.y[:, np.newaxis])
            self.A1 = self.A1.tocsr()

    def obj(self, x, idx, n=1, return_objval=True):
        """"
        logistic regression
                f_i(x) = 1/num_instances * sum_{j=1}^num_instances ( log( 1 + exp(- yi a_i^T x)) + 0.5 * reg * x^T x )
          #:param A: data matrix
          #:param x: variable
          #:param y: label
          #:param n: number of agents
          #:param idx: row index of A and y
          #:param return_objval: whether return objective value
          #:param sparse_mat: whether A is a csr sparse matrix
          #:return a sub-gradient vector:  partial f(x)
          #:return obj val: f(x)
        """
        if not self.sparse_mat:
            full_idx = np.arange(self.num_instances)
            if idx.size == full_idx.size and (idx == full_idx).all():
                """full grad """
                h = sigmoid(self.A1, x)
                grad = np.dot(self.A1.T, (h - 1)) / idx.size + self.reg * x
            elif idx.size == 0:
                """ empty idx """
                return np.zeros(x.shape), None
            else:
                """ batch grad """
                h = sigmoid(self.A1[idx, :], x)
                grad = np.dot(self.A1[idx, :].T, (h - 1)) / idx.size + self.reg * x
            if return_objval is False:
                return grad, None
            else:
                # return grad, (-self.y * np.log(h) - (1 - self.y) * np.log(1 - h)).mean()
                return grad, - np.log(h).mean() + 0.5 * self.reg * la.norm(x) ** 2
        else:
            " sparse matrix "
            full_idx = np.arange(self.num_instances)
            if idx.size == full_idx.size and (idx == full_idx).all():
                """full grad """
                h = sigmoid(self.A1, x, sparse_mat=True)
                grad = sparse.csr_matrix.dot(self.A1.T, (h - 1)) / idx.size + self.reg * x
            elif idx.size == 0:
                """ empty idx """
                return np.zeros(x.shape), None
            else:
                """ batch grad """
                if idx.size == 1:
                    idx = int(idx)
                    d1 = self.A1.data[self.A1.indptr[idx]:self.A1.indptr[idx+1]]
                    i1 = self.A1.indices[self.A1.indptr[idx]:self.A1.indptr[idx+1]]
                    a_dense = np.zeros(x.size)
                    a_dense[i1] = d1
                    h = sigmoid(d1, x[i1], sparse_mat=False)
                    grad = np.dot(a_dense.T, (h-1)) + self.reg * x
                else:
                    a1 = self.A1[idx, :]
                    h = sigmoid(a1, x, sparse_mat=True)
                    grad = sparse.csr_matrix.dot(a1.T, (h - 1)) / idx.size + self.reg * x
            if return_objval is False:
                return grad, None
            else:
                return grad, - np.log(h).mean() + 0.5 * self.reg * la.norm(x) ** 2

    def init_point(self):
        x_init = np.zeros(self.dimension)
        return x_init

    def accuracy(self, x):
        if self.sparse_mat:
            val = np.maximum(np.sign(sparse.csr_matrix.dot(self.A1, x)), 0)
            print(val)
            accur = val.sum() / self.num_instances
        else:
            val = np.maximum(np.sign(np.dot(self.A1, x)), 0)
            accur = val.sum() / self.num_instances

        print(f'accuracy:{100 * accur: .3f} %')


if __name__ == '__main__':
    sparse_mat = True

    # from joblib import Memory
    # from sklearn.datasets import load_svmlight_file
    # mem = Memory("./mycache")
    #
    # @mem.cache
    # def get_data():
    #     data = load_svmlight_file("a9a")
    #     return data[0], data[1]
    #
    # A1, y = get_data()
    with open('a9a_mat.npz', 'rb') as f:
        A = scipy.sparse.load_npz(f)
    f.close()
    with open('a9a_label.npy', 'rb') as f:
        y = np.load(f)
    f.close()
    num_instances, dimension = A.shape
    if not sparse_mat:
        A = A.A
    model = LogisticRegression(num_instances, dimension, A=A, y=y, regularization=1e-5, sparse_mat=sparse_mat)
    del A, y
    # num_instances, dimension = 31000, 123
    # model = LogisticRegression(num_instances, dimension, sparse_mat=sparse_mat)
    # model.synthetic_data()
    batch_size = 1 #  'full'
    print('batch size:', batch_size)
    Epoch = 10
    tol = 1e-16
    stepsize_type = ['1/k', '1/sqrtk', 'constant']

    step_size_t = stepsize_type[2]

    if isinstance(batch_size, int):
        # 50 * batch_size / (num_instances * Epoch * np.sqrt(dimension))
        step_init = 0.01  # dim = 100, n = 10**4
    else:
        # if sparse_mat:
        #     _, s, _ = scipy.sparse.linalg.svds(model.A, which='LM', k=1)
        # else:
        #     _, s, _ = la.svd(model.A, full_matrices=False)
        step_init = 2  # 1/s[0]**2
    print('step size:', step_init)

    np.random.seed(2021)
    x = np.random.randn(dimension)  # random initialization
    x = model.init_point()  # initialization  for non-noisy data
    model.accuracy(x)
    obj_val = []
    grad_norm = []
    time_record = []


    def objective(x, idx, return_objval=True):
        return model.obj(x=x, idx=idx, return_objval=return_objval)


    import time

    start_time = time.time()
    step_size = step_init
    for i in range(Epoch):

        if batch_size == 'full':
            """ full gradient """
            idx = np.arange(num_instances)
            grad, fval = objective(x, idx=idx)

            if step_size_t == '1/sqrtk':
                step_size = step_init / np.sqrt(i)
            elif step_size_t == '1/k':
                step_size = step_init / i
            elif step_size_t == 'constant':
                step_size = step_init

            if step_size < tol:
                break
            # print(step_size/step_size_old)
            x -= step_size * grad
        else:
            """ stochastic gradient step, one epoch """
            if step_size_t == '1/sqrtk':
                step_size = step_init / np.sqrt(i)
            elif step_size_t == '1/k':
                step_size = step_init / i
            elif step_size_t == 'constant':
                step_size = step_init
            if step_size < tol:
                break
            num = np.int(np.ceil(num_instances / batch_size))
            sample = np.random.permutation(num_instances)
            end = 0
            for _ in range(num):
                # idx = np.random.randint(0, num_instances, batch_size)
                start = end
                end = start + batch_size
                idx = sample[start: end]
                grad, objective_val = objective(x, idx=idx, return_objval=False)
                x -= step_size * grad
            grad, fval = objective(x, idx=np.arange(num_instances), return_objval=True)
        time_record.append(time.time() - start_time)
        obj_val.append(fval)
        grad_norm.append(la.norm(grad))

    print('time', time.time() - start_time)
    print({'time': time_record})
    print({'obj val': obj_val})

    model.accuracy(x)

    import matplotlib.pyplot as plt

    f_min = np.array(obj_val).min()
    plt.plot(np.array(obj_val) - f_min)
    plt.yscale('log', base=10)
    plt.xlabel('Epoch')
    plt.ylabel(r'$f( {X}_k) - f^*$')
    plt.show()
