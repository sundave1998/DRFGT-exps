"""
Demo of Riemannian decentralized tracking gradient method for solving
            max_X sum_{i=1}^N f_i(x_i)
            s.t.  x_1 = x_2 = ... x_N, and x_i^T x_i = Identity
        where N is the number of devices
        f_i(x_i) = 0.5* trace( x_i^T A_i x_i)
        A is data matrix with size of (row, col) = (matrix_row_n , matrix_col_n)
        A_i is obtained by divided A into N parts
        x_i's size: matrix_col_n, var_col_n
"""
import numpy as np
from mpi4py import MPI
from misc.Graph import Graph
from Quadratic_object.Quadraic import quadratic
from misc.decentralized_RGD import DecenRiemannianGradient
from misc.ManifoldToolbox import StiefelManifold

comm = MPI.COMM_WORLD
size = MPI.COMM_WORLD.Get_size()
rank = MPI.COMM_WORLD.Get_rank()
# name = MPI.Get_processor_name()


def orth(x):
    return StiefelManifold.orthogonalize(x)


def demo(data_size, log_=True, plot=True, objective=None, comp_objval=True):
    """
    Demo for the use of the centralized RGD.
        data_size = (matrix_row_n, matrix_col_n, var_col_n)
        number_agent: number of agents
        data_size: (matrix row number, matrix col number, variable col number)
        log_: whether record the  results
        plot: whether plot the results
        objective: objective function; should return (sub)gradient and function value(optional) if comp_objval is True
        comp_objval: whether compute objective value
    """

    Num_instances = data_size[0]
    Dimension = data_size[1]
    number_agent = size
    count = Num_instances // size
    remainder = Num_instances % size

    if rank == 0:
        global_data = np.random.randn(Num_instances, Dimension)

        print("data matrix shape:", global_data.shape, ";", "variable shape:", (data_size[1], data_size[2]))
        graph_type = ['Ring', 'ER']
        weighted_type = ['max_degree', 'metropolis_hastings']
        graph = Graph(graph_type=graph_type[0], weighted_type=weighted_type[0],
                      N=number_agent, p=0.3, plot_g=False)
        print("The edges of graph:", graph.peer)
        if rank < remainder:
            # The first 'remainder' ranks get 'count + 1' tasks each
            start = 0
            stop = start + count
        else:
            # The remaining 'size - remainder' ranks get 'count' task each
            start = 0
            stop = start + (count - 1)
        local_data = global_data[:, start:stop + 1]
        weighted = graph.W[0, :]
        peer = graph.peer[0]

        for i in range(1, size):
            if i < remainder:
                # The first 'remainder' ranks get 'count + 1' tasks each
                start = i * (count + 1)
                stop = start + count
            else:
                # The remaining 'size - remainder' ranks get 'count' task each
                start = i * count
                stop = start + (count - 1)

            # divide global_data into local data
            sendbuf = np.append(global_data[start:stop+1,:], graph.W[i, :])
            comm.Send(sendbuf, dest=i)

    elif rank < remainder:
        recvbuf = np.empty((count + 1) * Dimension + number_agent)
        comm.Recv(recvbuf, source=0)
        local_data = recvbuf[:(count + 1) * Dimension].reshape(count + 1, Dimension)
        weighted = recvbuf[(count + 1) * Dimension:(count + 1) * Dimension + size].reshape(size)
        # peer = recvbuf[(count+1)*Dimension+size:]
    else:
        recvbuf = np.empty(count * Dimension + number_agent)
        comm.Recv(recvbuf, source=0)
        local_data = recvbuf[:count * Dimension].reshape(count, Dimension)
        weighted = recvbuf[count * Dimension:].reshape(size)

    """ run the algorithm """
    np.random.seed(seed=rank)
    var_col_n = data_size[2]
    x_start = np.random.randn(Dimension, var_col_n)
    x_start = orth(x_start)  # initial point
    obj = lambda x: objective(local_data, x, return_objval=comp_objval)

    alg = DecenRiemannianGradient(objective=obj,
                                  arg_start=x_start,
                                  synch=True,
                                  weight=weighted,
                                  step_size_consensus=1,
                                  stepsize_type='1/k',
                                  stepsize_init=1,
                                  gamma=0.1/Dimension,
                                  terminate_by_time=False,
                                  termination_condition=5e3,
                                  log=log_,
                                  num_consensus_itr=1)
    # run optimization method
    alg_log = alg.minimize()
    if rank == 0 and alg.log:
        print('-----------------------------------------')
        logfile = alg_log['Log']
        logfile.print_rgd_value()  # print result
        from storFile import store_file
        store_file(logfile.time_history, 'decentralized_GD.csv')
        if plot:
            from misc.Plot import plot
            plot(logfile, grad=True, objval=comp_objval)
    elif rank == 0 and not alg.log:
        print(f"         average_grad norm:{alg_log['ave_gradient']:.3e}\n")

    return alg_log


matrix_row_n, matrix_col_n, var_col_n = 5000, 100, 1
Result = demo(data_size=(matrix_row_n, matrix_col_n, var_col_n), log_=True, plot=True, objective=quadratic, comp_objval=True)

