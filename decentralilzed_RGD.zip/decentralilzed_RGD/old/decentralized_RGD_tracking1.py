""" Decentralized Riemannian Gradient Tracking method on Stiefel manifold. """
import time
import numpy as np
import scipy.linalg as la
from mpi4py import MPI

from Quadratic_object.Quadraic import quadratic
from StiefelManifoldToolbox import StiefelManifold
from push_sum_optimization import PushSumOptimizer

Stiefel = StiefelManifold()


def orth(x): return Stiefel.orthogonalize(x)


def proj_tangent(x, d): return Stiefel.proj_tagent(x, d)


def retraction(x, d): return Stiefel.polar_r(x, d)


# COMM = GossipComm.comm
# SIZE = GossipComm.size
# UID = GossipComm.uid
# NAME = GossipComm.name
comm = MPI.COMM_WORLD
size = MPI.COMM_WORLD.Get_size()
rank = MPI.COMM_WORLD.Get_rank()
name = MPI.Get_processor_name()


class DecenRiemannianGradient(PushSumOptimizer):
    # Inherit docstring
    # __doc__ += PushSumOptimizer.__doc__
    def __init__(self, objective,
                 arg_start,
                 synch=True,
                 graph=None,
                 step_size_consensus=1,
                 step_size_grad=None,
                 terminate_by_time=False,
                 termination_condition=None,
                 log=False,
                 out_degree=None,
                 in_degree=size,
                 num_averaging_itr=1,
                 all_reduce=False,
                 constant_weight=True):
        """ Initialize the decentralized optimization settings. """
        self.objective = objective
        self.arg_start = arg_start
        self.step_size_consensus = step_size_consensus
        self.step_size_grad = step_size_grad
        self.peers = graph.peer[rank],
        self.terminate_by_time = terminate_by_time
        self.termination_condition = termination_condition
        self.log = log

        """ Initialize the mpi settings. """
        super(DecenRiemannianGradient,   self).__init__(objective=objective,
                                                         arg_start=arg_start,
                                                         synch=synch,
                                                         peers=self.peers,
                                                         step_size=None,
                                                         terminate_by_time=terminate_by_time,
                                                         termination_condition=termination_condition,
                                                         log=log,
                                                         out_degree=out_degree,
                                                         in_degree=in_degree,
                                                         num_averaging_itr=num_averaging_itr,
                                                         all_reduce=all_reduce,
                                                         constant_weight=constant_weight)

    def minimize(self):
        super(DecenRiemannianGradient, self).minimize()
        consensus = self.ps_averager
        objective = self.objective
        # ----Initialize push diging----#
        iter = 0
        step_alpha = self.step_size_consensus
        step_beta = self.step_size_grad
        x = self.arg_start  # initial variable
        ps_w = 1.0
        grad, objective_val = objective(x)
        rgrad = proj_tangent(x, grad)  # Riemannian gradient
        tracking_grad = rgrad   # gradient tracking variable
        rgrad_old = rgrad

        # set up log
        log = self.log
        if log:
            from logfile import Log
            RGD_log = Log()  # Log the variable, gradient, iteration

        if not self.terminate_by_time:
            num_iter_RGD = self.termination_condition
            stop_criteria = iter < num_iter_RGD
        else:
            end_time = time.time() + self.termination_condition
            stop_criteria = time.time() < end_time

        stop_condition_global = True
        # Start optimization at the same time
        comm.Barrier()  # no process could pass this barrier until they all call it
        # iteration step of the decentralized Riemannian gradient tracking method
        while stop_criteria:
            if self.synch:
                comm.Barrier()  # synchronize

            # Take a gossip
            gossip_vector = np.append(x, tracking_grad)
            ps_result = consensus.gossip(gossip_value=gossip_vector, ps_weight=ps_w)

            # update consensus step
            ps_w = ps_result['ps_w']
            ps_n = np.array(ps_result['ps_n'])
            ps_argmin_n = ps_n[:x.size].reshape(x.shape)
            local_average = ps_argmin_n / ps_w
            print(ps_w)
            consens_grad = proj_tangent(x, local_average)
            # -- update RGD-tracking iteration  -- #
            v = proj_tangent(x, tracking_grad)
            x = retraction(x, step_alpha*consens_grad + step_beta*v)

            # update gradient tracking estimate
            grad, objective_val = objective(x)
            rgrad = proj_tangent(x, grad)  # update Riemannian gradient
            # rgrad_norm = la.norm(rgrad)
            tracking_grad = ps_n[x.size:].reshape(tracking_grad.shape)
            tracking_grad += rgrad - rgrad_old

            # Update the past gradient (at itr. k minus 1)
            rgrad_old = rgrad
            norm_tracking_grad = la.norm(tracking_grad)
            if rank == 0:
                if log:
                    RGD_log.log(norm_tracking_grad, iter, objval=objective_val)
                # collect all norm of y_i
                if norm_tracking_grad < 1e-4:
                    stop_condition_global = False

            iter += 1
            if self.terminate_by_time is False:
                # num_iter_RGD = self.termination_condition
                stop_criteria = iter < num_iter_RGD
            else:
                end_time = time.time() + self.termination_condition
                stop_criteria = time.time() < end_time

            stop_condition_global = comm.bcast(stop_condition_global, root=0)  # broadcast from root 0 to all roots
            stop_criteria = (stop_criteria and stop_condition_global)
        # compute the average point and average gradient
        average_variable = np.empty(grad.shape, dtype=np.float)
        comm.Reduce(x, average_variable, MPI.SUM, 0)
        average_grad = np.empty(grad.shape, dtype=np.float)
        comm.Reduce(rgrad, average_grad, MPI.SUM, 0)    # collection average gradient to root 0
        ave_grad_norm = la.norm(average_grad)
        if rank == 0:
            # self.argmin_est = x
            if log:
                RGD_log.log(ave_variable=average_variable, ave_grad_norm=ave_grad_norm)
                return {"Log": RGD_log}
            else:
                return {"ave_variable": average_variable,
                        "ave_gradient": ave_grad_norm}
        return None


if __name__ == '__main__':

    def demo(number_agent,  data_size, graph, log_=True, plot=True, comp_objval=True):
        """
        Demo for the use of the centralized RGD.
        Create objective function and its gradient
            number_agent: number of agents
            data_size: (matrix row number, matrix col number, variable col number)
            log_: whether record the  results
            plot: whether plot the results
            comp_objval: whether compute objective value
        """
        # divide global_data into local data
        num_instances, dimension = local_data.shape

        np.random.seed(seed=rank)
        x_start = np.random.randn(data_size[1], data_size[2])
        x_start = orth(x_start)  # initial point
        obj = lambda x: quadratic(local_data, x, return_objval=comp_objval)
        alg = DecenRiemannianGradient(objective=obj,
                                      arg_start=x_start,
                                      synch=True,
                                      graph=graph,
                                      step_size_consensus=1,
                                      step_size_grad=.1/dimension,
                                      terminate_by_time=False,
                                      termination_condition=5e3,
                                      log=log_,
                                      out_degree=None,
                                      in_degree=2,
                                      num_averaging_itr=1,
                                      constant_weight=True)
        # run optimizer
        alg_log = alg.minimize()
        if rank == 0 and alg.log:
            print('-----------------------------------------')
            logfile = alg_log['Log']
            logfile.print_rgd_value()   # print result
            if plot:
                from misc.Plot import plot
                plot(logfile, grad=True, objval=comp_objval)
        elif not alg.log:
            print(f"         average_grad norm:{alg_log['ave_gradient']:.3e}\n")
        return alg_log


    """
         Run a demo where nodes minimize a sum of squares function
            Num_instances: Num_instances * Dimension
            Dimension: dimension of feature;
            col_n: rank of feature;
            Result['ave_variable']: induced arithmetic mean of all roots
            Result['ave_gradient']: Frobenius norm of the average Riemannian gradient
     """


    Result = demo(local_data, number_agent=number_agent, data_size=(matrix_row_n, matrix_col_n, var_col_n), graph=graph)

