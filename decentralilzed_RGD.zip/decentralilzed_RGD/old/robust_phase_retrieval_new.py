from scipy import sparse
import numpy as np
import scipy.linalg as la
from scipy.linalg import hadamard
import time


class RobustPhaseRetrieval:
    """"
   robust phase retrieval  f_i(x) = 1/num_instances * sum_{j=1}^num_instances | (a_j^T x)^2 - y_j |
     #:param num_instances: number of instances at local node
             dimension: dimension of variable
             m:  maximum number of instances across all nodes, only needed for decentralized alg
             data=[A, y], where A is measurement vectors and y is signal amplitudes
             idx: row index of A and y
             sparse_mat: whether A is a csr sparse matrix
     #:return a sub-gradient vector:  partial f(x)
              obj val: f(x)
    """
    def __init__(self, num_instances=0, dimension=0, m=1, data=np.empty([1,1]), x_true=[], sparse_mat=False):
        self.num_instances = num_instances
        self.dimension = dimension
        self.m = m
        self.A = data[:, :-1]
        self.y = data[:, -1]
        self.x_true = x_true
        self.sparse_mat = sparse_mat

    def synthetic_data(self):
        """ generate data """
        np.random.seed(2021)
        self.A = np.random.randn(self.num_instances, self.dimension)
        print(self.A.shape)
        self.x_true = np.random.randn(self.dimension)
        self.y = np.empty(self.num_instances)
        for i in range(self.num_instances):
            self.y[i] = np.matmul(self.A[i, :].T, self.x_true) ** 2

    def obj(self, x, idx, n=1, return_objval=True):
        """"
        robust phase retrieval function: f_i(x) = 1/num_instances * sum_{j=1}^num_instances | (a_j^T x)^2 - y_j |
          #:param A: data matrix
          #:param x: variable
          #:param y: signal intensity
          #:param n: number of agents
          #:param idx: row index of A and y
          #:param return_objval: whether return objective value
          #:param sparse_mat: whether A is a csr sparse matrix
          #:return a sub-gradient vector:  partial f(x)
          #:return obj val: f(x)
        """
        if not self.sparse_mat:
            full_idx = np.arange(self.num_instances)
            if idx.size == full_idx.size and (idx == full_idx).all():
                """full grad """
                ax = np.matmul(self.A, x)
                ax_y = np.square(ax) - self.y
                temp = np.sign(ax_y) * ax
                subgrad = np.multiply(self.A, temp[:, np.newaxis]).sum(axis=0) / idx.size
            elif idx.size == 0:
                """ empty idx """
                return np.zeros(x.shape), None
            else:
                """ batch grad """
                ax = np.matmul(self.A[idx, :], x)
                ax_y = np.square(ax) - self.y[idx]
                temp = np.sign(ax_y) * ax
                subgrad = np.multiply(self.A[idx, :], temp[:, np.newaxis]).sum(axis=0) / idx.size
            if return_objval is False:
                return subgrad, None
            else:
                return subgrad, la.norm(ax_y, 1) / (n*idx.size)
        else:
            ax = sparse.csr_matrix.dot(self.A, x)
            ax_y = np.square(ax) - self.y
            temp = np.sign(ax_y)*ax
            subgrad = self.A.multiply(temp[:, np.newaxis]).sum(axis=0)
            if return_objval is False:
                return subgrad, None
            else:
                return subgrad, la.norm(ax_y, 1)

    def init_point(self):
        r = np.mean(self.y)
        index = np.where(self.y <= 0.5*r)
        X = np.zeros([self.dimension, self.dimension])
        for i in np.nditer(index):
            X = X + np.matmul(self.A[i, :], self.A[i, :].T)
        eigenValues, eigenVectors = la.eig(X)
        idx = eigenValues.argsort()[::-1]
        eigenVectors = eigenVectors[:, idx]
        x_init = np.sqrt(r)*eigenVectors[:, -1]
        return x_init

    def distance(self, x):
        dist = min(la.norm(x-self.x_true), la.norm(x+self.x_true))
        print(f'distance:{dist: .3e}')


if __name__ == '__main__':
    start_time = time.time()
    num_instances, dimension = 3*10**4, 10**4
    model = RobustPhaseRetrieval(num_instances, dimension)
    model.synthetic_data()
    batch_size = 'full'  # 10
    print('batch size:', batch_size)
    Epoch = 2000
    tol = 1e-16
    stepsize_type = ['1/k', '1/sqrtk', 'geo_diminishing', 'constant']

    step_size_t = stepsize_type[2]
    # constant
    # step_init = 50*batch_size/(num_instances*Epoch*np.sqrt(dimension))  # dim = 100, n = 10**4
    # step_init = 200*batch_size/(num_instances*Epoch*np.sqrt(dimension)) # dim = 10**3, n=10**5
    # step_init = 1000*batch_size/(num_instances*Epoch*np.sqrt(dimension))  # dim = 10**4, n=10**5

    # 1/sqrt(k)
    if isinstance(batch_size, int):
        # 50 * batch_size / (num_instances * Epoch * np.sqrt(dimension))
        step_init = 100 * batch_size / (num_instances * Epoch * np.sqrt(dimension))  # dim = 100, n = 10**4
    else:
        # step_init = 2.5   # 2.5, 0.67   num_instances, dimension = 10**5, 10**2
        # step_init = 3   # 3, 0.65   num_instances, dimension = 10**4, 10**2
        # step_init = 30  # 20, 0.75   num_instances, dimension = 5*10**3, 10**2
        # step_init = 100   # 100, 0.95   num_instances, dimension = 5*10**2, 10**2
        # step_init = 300   # 300, 0.95   num_instances, dimension = 3*10**2, 10**2
        # step_init = 200   # 200, 0.97   num_instances, dimension = 2*10**2, 10**2
        step_init = 500

    gamma = 0.995

    np.random.seed(2021)
    x = np.random.randn(dimension)
    # x = robust_ph_r.init_point()
    model.distance(x)
    obj_val = []
    grad_norm = []
    time_record = []

    def objective(x, idx, return_objval=True):
        return model.obj(x=x, idx=idx, return_objval=return_objval)

    for i in range(Epoch):
        if step_size_t == '1/sqrtk':
            step_size = step_init / np.sqrt(i)
        elif step_size_t == '1/k':
            step_size = step_init / i
        elif step_size_t == 'geo_diminishing':
            step_size = step_init * pow(gamma, i)
        elif step_size_t == 'constant':
            step_size = step_init

        if step_size < tol:
            break
        if batch_size == 'full':
            """ full gradient """
            idx = np.arange(num_instances)
            grad, objective_val = objective(x, idx=idx)
            x -= step_size*grad
        else:
            """ stochastic gradient step, one epoch """
            num = np.int(np.ceil(num_instances / batch_size))
            sample = np.random.permutation(num_instances)
            end = 0
            for i in range(num):  # all agents should have same iterations to aviod deadlock
                # idx = np.random.randint(0, num_instances, batch_size)
                start = end
                end = start + batch_size
                idx = sample[start: end]
                grad, objective_val = objective(x, idx=idx)
                x -= step_size * grad

        grad, fval = objective(x, idx=np.arange(num_instances), return_objval=True)
        time_record.append(time.time() - start_time)
        # x = x - np.power(0.9, i)*subg
        obj_val.append(fval)
        grad_norm.append(la.norm(grad))
    print(min(obj_val))
    model.distance(x)
    print(time.time() - start_time)
    print({'time': time_record})
    print({'obj val': obj_val})

    import matplotlib.pyplot as plt

    plt.plot(obj_val)
    plt.yscale('log', basey=10)
    plt.xlabel('Epoch')
    plt.ylabel(r'$f( {X}_k) - f^*$')
    plt.show()
