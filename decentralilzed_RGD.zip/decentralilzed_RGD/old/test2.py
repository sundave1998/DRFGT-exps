import multiprocessing
from multiprocessing import Pool
import numpy as np
import time


def my_function(i, param1, param2, param3):
    result = param1 ** 2 * param2 + param3
    time.sleep(2)
    return (i, result)


def get_result(result):
    global results
    results.append(result)


if __name__ == '__main__':
    params = np.random.random((10, 3))
    # results = []
    # ts = time.time()
    # for i in range(0, 3):
    #     get_result(my_function(i, params[i, 0], params[i, 1], params[i, 2]))
    # print('Time in serial:', time.time() - ts)
    # print(results)

    results = []
    ts = time.time()
    print(multiprocessing.cpu_count())
    pool = Pool(2)
    # for i in range(0, 5):
    #     pool.apply_async(my_function, args=(i, params[i, 0], params[i, 1], params[i, 2]), callback=get_result)
    i = 0
    res = pool.apply_async(my_function, args=(i, params[i, 0], params[i, 1], params[i, 2]), callback=get_result)
    # print(res.get())
    i = 1
    pool.apply_async(my_function, args=(i, params[i, 0], params[i, 1], params[i, 2]), callback=get_result)
    pool.close()
    pool.join()
    print('Time in parallel:', time.time() - ts)
    print(results)


# import ray
#
# ray.init()
#
# # Define the functions.
#
# @ray.remote
# def solve1(a):
#     return 1
#
# @ray.remote
# def solve2(b):
#     return 2
#
# # Start two tasks in the background.
# x_id = solve1.remote(0)
# y_id = solve2.remote(1)
#
# # Block until the tasks are done and get the results.
# x, y = ray.get([x_id, y_id])