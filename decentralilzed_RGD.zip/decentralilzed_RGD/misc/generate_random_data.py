import numpy as np
from robust_phase_retrieval import RobustPhaseRetrieval
import os
m, n = 5*10**3, 5*100
global_model = RobustPhaseRetrieval(num_instances=m, dimension=n)
global_model.synthetic_data()
global_data = np.zeros([m, n+1])
global_data[:, :-1] = global_model.A
global_data[:, -1] = global_model.y
if not os.path.isdir("Robust_phase_synthetic"):
    os.makedirs("Robust_phase_synthetic")
filename = os.path.join('Robust_phase_synthetic', 'RP_synthetic.npy')
np.save(filename, global_data)

filename_1 = os.path.join('Robust_phase_synthetic',  'RP_op.npy')
np.save(filename_1, global_model.x_true)