import datetime
import numpy as np
from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.pyplot as plt
import os
list_file = os.listdir(os.getcwd())
pdf = []
for filename in list_file[1:]:
    f1 = plt.imread(filename)