from mpi4py import MPI
import numpy as np

from misc.Graph import Graph
from misc.decentralized_alt_RGD import DecenRiemannianGradientAlternatingDescent
from misc.decentralized_alt_RGD_retfree import DecenRiemannianGradientAlternatingDescentRetFree
from misc.ManifoldToolbox import StiefelManifold, Euclidean  # set manifold
from variable_selection_sparsification.var_sparse_low_rank import Quadratic

from variable_selection_sparsification.run_algorithm_var_select import demo


comm = MPI.COMM_WORLD
size = MPI.COMM_WORLD.Get_size()
rank = MPI.COMM_WORLD.Get_rank()
"""
The following code is the demo of   decentralized  Riemannian  gradient  descent for solving
            min_X  sum_{i=1}^n f_i(x_i)
            s.t.  x_1 = x_2 = ... x_n, and and x_i on Stiefel manifold
        where n=size is the number of devices/processes/cores
        f_i(x_i) = 0.5* trace(  (A_i x_i)^T  A_i x_i )
        A is data matrix with size of (row, col) = (matrix_row_n , matrix_col_n)
        A_i is obtained by divided A into n partitions
        x_i's size: matrix_col_n, var_col_n
"""
'''==================================================================='''
""" 
set data size
data matrix A_i size: (sample_size, var_dim)
variable size: (var_dim, var_col)
"""
sample_size, var_dim, q, var_col = size*50, 30, 10, 5
""" 
 set graph, in this demo, we use the ring graph, and the weighted rule is given by metropolis_hastings
"""
graph_type = ['Ring', 'ER', 'star', 'complete']
weighted_type = ['Laplacian-based', 'lazy_metropolis', 'metropolis_hastings']
Er_probability = 0.3
graph_set = (graph_type[0], weighted_type[2], Er_probability)


""" initial point """
# np.random.seed(seed=1)
x_start = np.random.randn(q, var_col)
x_start = StiefelManifold.proj_manifold(x_start)
y_start = np.ones([var_dim, var_col])
""" termination """
max_iter, tol = 10**4, 1e-8

batch_size = 'full'
""" multi-step consensus """
T_1, T_2 = 1, 10
"""stepsize"""
"""
set stepsize 
    if stepsize_type == '1/k':
        stepsize = grad_stepsize[0]/iteration
    if stepsize_type == '1/sqrtk':
        stepsize = grad_stepsize[0]/sqrt(iteration)
    if stepsize_type == 'constant':
        stepsize = grad_stepsize[0]  
"""
stepsize_type = ['1/k', '1/sqrtk', 'constant']

beta_hat = np.array([0.01, 0.02, 0.03, 0.04, 0.05])
beta_x = 0.1*beta_hat * size / sample_size
beta_y = beta_hat * size / sample_size

# print('stepsize', small_step)
""" 
run demo of quadratic minimization on the Stiefel manifold 
"""
if rank == 0:
    """"create  global model """
    global_model = Quadratic(num_instances=sample_size, dimension=var_dim, q=q, col=var_col)
    global_model.synthetic_data()
    print('==========================   New case  =============================')
    print("data matrix shape:", sample_size, ";", "variable shape:", (var_dim, var_col))
    graph = Graph(graph_type=graph_set[0], weighted_type=graph_set[1],
                  N=size, p=graph_set[2], plot_g=False)
    print("The peers of graph:", graph.peer)
else:
    global_model = None
    graph = None

mu_para_1, mu_para_2 = 1, 2

""" 
run demo of quadratic minimization on the Stiefel manifold 
"""
import os
files_name = "Sparse_var_selection" + str(size) + '_DRSGD_results'
if rank == 0:
     if not os.path.isdir(files_name):
         os.makedirs(files_name)

""" decentralized algorithms """
for i in range(len(beta_hat)):
     save_file_name = os.path.join(files_name, 'MPI_' + str(size)
                                   + 'DRSGD_'+ str(T_1) + str(beta_hat[i]) + 'ret.pkl')
     demo(Alg=DecenRiemannianGradientAlternatingDescent,
         global_model=global_model,
         f_obj=Quadratic,
         x_start=x_start,
         y_start=y_start,
         data_size=(sample_size, var_dim, var_col, q, mu_para_1, mu_para_2),
         graph_setting=graph_set,
         graph=graph,
         manifold=StiefelManifold,
         consensus_stepsize=1,
         grad_stepsize_x=beta_x[i],
         grad_stepsize_y=beta_y[i],
         step_size_type=stepsize_type[-1],
         multi_step_consen=T_1,
         batch_size=batch_size,
         termination_cond=(max_iter, tol),
         comp_objval=True,
         stop_by_time=False,
         record_consensus_error=True,
         plot=False,
         filename=save_file_name)

""" decentralized retration-free algorithms """
for i in range(len(beta_hat)):
     save_file_name_retfree = os.path.join(files_name, 'MPI_' + str(size)
                                   + 'DRSGD_'+ str(T_1) + str(beta_hat[i]) + 'retfree.pkl')
     demo(Alg=DecenRiemannianGradientAlternatingDescentRetFree,
         global_model=global_model,
         f_obj=Quadratic,
         x_start=x_start,
         y_start=y_start,
         data_size=(sample_size, var_dim, var_col, q, mu_para_1, mu_para_2),
         graph_setting=graph_set,
         graph=graph,
         manifold=StiefelManifold,
         consensus_stepsize=1,
         grad_stepsize_x=beta_x[i],
         grad_stepsize_y=beta_y[i],
         step_size_type=stepsize_type[-1],
         multi_step_consen=T_1,
         batch_size=batch_size,
         termination_cond=(max_iter, tol),
         comp_objval=True,
         stop_by_time=False,
         record_consensus_error=True,
         plot=False,
         filename=save_file_name_retfree)



# demo(Alg=DecenRiemannianGradientStochasticDescent,
#      global_model=global_model,
#      f_obj=Quadratic,
#      x_start=x_start,
#      data_size=(sample_size, var_dim, var_col, p, mu_para_1, mu_para_2),
#      graph_setting=graph_set,
#      graph=graph,
#      manifold=StiefelManifold,
#      consensus_stepsize=1,
#      step_size_type='constant',
#      grad_stepsize=small_step,
#      multi_step_consen=T_2,
#      batch_size=batch_size,
#      termination_cond=(max_iter, tol),
#      comp_objval=True,
#      stop_by_time=False,
#      record_consensus_error=True,
#      plot=False,
#      filename='DRDGD_'+ str(T_2) + '_small_stepsize.pkl')
#
# demo(Alg=DecenRiemannianGradientStochasticDescent,
#      global_model=global_model,
#      f_obj=Quadratic,
#      x_start=x_start,
#      data_size=(sample_size, var_dim, var_col, p, mu_para_1, mu_para_2),
#      graph_setting=graph_set,
#      graph=graph,
#      manifold=StiefelManifold,
#      consensus_stepsize=1,
#      grad_stepsize=large_step,
#      step_size_type='constant',
#      multi_step_consen=T_2,
#      batch_size=batch_size,
#      termination_cond=(max_iter, tol),
#      comp_objval=True,
#      stop_by_time=False,
#      record_consensus_error=True,
#      plot=False,
#      filename='DRDGD_'+ str(T_2) + '_large_stepsize.pkl')
#
#
# """ complete graph, equally weighted """
# graph_set_1 = (graph_type[-1], weighted_type[0], Er_probability)
# if rank == 0:
#     graph1 = Graph(graph_type=graph_set_1[0], weighted_type=graph_set[1],
#                   N=size, p=graph_set[2], plot_g=False)
#     print("The peers of graph:", graph.peer)
# else:
#     global_model = None
#     graph1 = None
#
# demo(Alg=DecenRiemannianGradientStochasticDescent,
#      global_model=global_model,
#      f_obj=Quadratic,
#      x_start=x_start,
#      data_size=(sample_size, var_dim, var_col, p, mu_para_1, mu_para_2),
#      graph_setting=graph_set_1,
#      graph=graph1,
#      manifold=StiefelManifold,
#      consensus_stepsize=1,
#      grad_stepsize=large_step,
#      step_size_type='constant',
#      multi_step_consen=1,
#      batch_size=batch_size,
#      termination_cond=(max_iter, tol),
#      comp_objval=True,
#      stop_by_time=False,
#      record_consensus_error=True,
#      plot=False,
#      filename='DRDGD_complete_consensus_large_stepsize.pkl')
