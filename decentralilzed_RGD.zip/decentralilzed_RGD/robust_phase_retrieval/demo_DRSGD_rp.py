from mpi4py import MPI
import numpy as np

from misc.Graph import Graph
from misc.decentralized_RGD import DecenRiemannianGradientStochasticDescent
from misc.ManifoldToolbox import Euclidean  # set manifold
from RobustPhaseretrieval.robust_phase_retrieval import RobustPhaseRetrieval

from RobustPhaseretrieval.run_phase_retrieval import demo


comm = MPI.COMM_WORLD
size = MPI.COMM_WORLD.Get_size()
rank = MPI.COMM_WORLD.Get_rank()
"""
Demo of   decentralized  Riemannian stochastic  gradient descent for solving
            min_X  sum_{i=1}^n f_i(x_i)
            s.t.  x_1 = x_2 = ... x_n, and and x_i in manifold
        where N is the number of devices
        f_i(x_i) = 0.5* trace(  (A_i x_i)^T  A_i x_i )
        A is data matrix with size of (row, col) = (matrix_row_n , matrix_col_n)
        A_i is obtained by divided A into N partitions
        x_i's size: matrix_col_n, var_col_n
"""
'''==================================================================='''
""" 
set data size
data matrix A_i size: (sample_size, var_dim)
variable size: (var_dim, var_col)
"""
sample_size, var_dim = size*10**4, 5*10**3
eigengap = 0.8
""" 
 set graph
"""
graph_type = ['Ring', 'ER', 'star', 'complete']
weighted_type = ['Laplacian-based', 'lazy_metropolis', 'metropolis_hastings']
Er_p = 0.3
graph_set = (graph_type[0], weighted_type[2], Er_p)

""" initial point """
np.random.seed(seed=1)
x_start = np.random.randn(var_dim)

""" termination """
max_iter, tol = 2, 1e-6
batch_size = 1
""" multi-step consensus """
T = 1
"""stepsize"""
"""
set stepsize 
    if stepsize_type == '1/k':
        stepsize = grad_stepsize[0]/iteration
    if stepsize_type == '1/sqrtk':
        stepsize = grad_stepsize[0]/sqrt(iteration)
    if stepsize_type == 'constant':
        stepsize = grad_stepsize[0]  
"""
stepsize_type = ['1/k', '1/sqrtk', 'constant']

# beta_hat = [0.001, 0.005, 0.01, 0.05]
beta_hat = np.array([0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1])
beta = beta_hat * np.sqrt(size) /(sample_size * pow(max_iter, 0.5))
""" 
run demo of quadratic minimization on the Stiefel manifold 
"""
import os
files_name = "RP_" + str(size) + '_DRSGD_results'
if rank == 0:
     if not os.path.isdir(files_name):
         os.makedirs(files_name)

""" decentralized algorithms """


""" 
run demo of robust phase retrieval problem
"""
if rank == 0:
    """"create  global model """
    with open('../Robust_phase_synthetic/RP_synthetic.npy', 'rb') as f:
        data_mat = np.load(f)

    sample_size, var_dim = data_mat.shape
    global_model = RobustPhaseRetrieval(sample_size, var_dim, data=data_mat)
    with open('../Robust_phase_synthetic/RP_op.npy', 'rb') as f:
        global_model.x_true = np.load(f)
    print('==========================   New case  =============================')
    print("data matrix shape:", (sample_size, var_dim-1), ";", "variable shape:", global_model.x_true.shape)
    graph = Graph(graph_type=graph_set[0], weighted_type=graph_set[1],
                  N=size, p=graph_set[2], plot_g=False)
    print("The peers of graph:", graph.peer)
else:
    global_model = None
    graph = None


""" decentralized algorithms """
for i in range(len(beta_hat)):
    save_file_name = os.path.join(files_name, 'MPI_' + str(size)
                               + 'DRSGD_' + str(beta_hat[i]) + '_rp.pkl')

    demo(Alg=DecenRiemannianGradientStochasticDescent,
         global_model=global_model,
         f_obj=RobustPhaseRetrieval,
         x_start=x_start,
         data_size=(sample_size, var_dim),
         graph_setting=graph_set,
         graph=graph,
         manifold=Euclidean,
         consensus_stepsize=1,
         grad_stepsize=beta[i],
         step_size_type='constant',
         multi_step_consen=T,
         batch_size=batch_size,
         termination_cond=(max_iter, tol),
         comp_objval=True,
         stop_by_time=False,
         record_consensus_error=True,
         plot=False,
         filename=save_file_name)
