from torchvision import datasets
import numpy as np
train_set = datasets.MNIST('./', train=True, download=True)
# test_set = datasets.MNIST('./data', train=False, download=True)
X_train = train_set.data.numpy()
# test_set_array = test_set.data.numpy()
X_train = X_train.reshape(X_train.shape[0], 784) / 255
_, _, vh = np.linalg.svd(X_train, full_matrices=False)
filename = 'MNIST_Train.npy'
np.save(filename, X_train)
filename_1 = 'MNIST_opt.npy'
np.save(filename_1, vh)
# with open('MNIST_mat.npz', 'rb') as f:
#     data_mat = np.load(f)
