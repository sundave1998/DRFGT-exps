import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif']=['SimHei']#设置字体以便支持中文
import numpy as np

x=np.arange(3)#柱状图在横坐标上的位置

# retraction - based
y1=[316.186, 163.488, 92.632] # total time
y2=[140.998, 70.332, 38.306]  # retraction time
y3=[80.455, 45.680, 28.585]   # communication time

# retraction - free
# y1=[263.596, 143.627, 78.543] # total time
# y3=[104.376, 69.532, 40.103]   # communication time

bar_width=0.3#设置柱状图的宽度
tick_label=['16','32','60']

#绘制并列柱状图
plt.bar(x,y1,bar_width,color='salmon',label='total time')
plt.bar(x+bar_width,y2,bar_width,color='red',label='retraction time')
plt.bar(x+2*bar_width,y3,bar_width,color='blue',label='communication time')



plt.rc('legend', fontsize=15)    # legend fontsize
plt.legend()#显示图例，即label
plt.xlabel('number of CPUs', fontsize=15)
plt.ylabel('time', fontsize=15)
plt.xticks(x+bar_width,tick_label, fontsize=15) #显示x坐标轴的标签,即tick_label,调整位置，使其落在两个直方图中间位置
large_font = 15
plt.rc('xtick', labelsize=13)    # fontsize of the x and y labels
plt.xticks(fontsize=large_font)
plt.rc('ytick', labelsize=15)
plt.yticks(fontsize=large_font)

plt.show()